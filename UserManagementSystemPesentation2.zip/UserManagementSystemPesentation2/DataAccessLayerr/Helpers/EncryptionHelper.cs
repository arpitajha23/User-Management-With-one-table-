﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayerr.Helpers
{
    public class EncryptionHelper
    {
        /* private static readonly string EncryptionKey = "b14ca5ygdd72ye7wb767r515a1916"; // 32 characters for 256-bit AES

         public static string Encrypt(string plainText)
         {
             using var aes = Aes.Create();
             aes.Key = Encoding.UTF8.GetBytes(EncryptionKey.PadRight(32).Substring(0, 32));
             aes.GenerateIV();

             var encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
             using var ms = new MemoryStream();
             using var cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write);
             using var sw = new StreamWriter(cs);
             sw.Write(plainText);

             var iv = aes.IV;
             var encryptedContent = ms.ToArray();
             var result = new byte[iv.Length + encryptedContent.Length];
             Buffer.BlockCopy(iv, 0, result, 0, iv.Length);
             Buffer.BlockCopy(encryptedContent, 0, result, iv.Length, encryptedContent.Length);

             return Convert.ToBase64String(result);
         }*/


        private static readonly string EncryptionKey = "b14ca5ygdd72ye7wb767r515a1916"; // 32 characters for 256-bit AES

        public static string Encrypt(string data)
        {
            if (string.IsNullOrEmpty(data))
            {
                return null;
            }
            else
            {
                byte[] storeData = ASCIIEncoding.ASCII.GetBytes(data);
                string encryptData = Convert.ToBase64String(storeData);
                return encryptData;
            }
        }

        public static string Decrypt(string data)
        {
            if (string.IsNullOrEmpty(data))
            {
                return null;
            }
            else
            {
                byte[] encryptedData = Convert.FromBase64String(data);
                string decryptData = ASCIIEncoding.ASCII.GetString(encryptedData);
                return decryptData;
            }
        }
    }
}



