﻿
using DataAccessLayerr.Models;
using Microsoft.EntityFrameworkCore;
using RepositoryLayer.IRepository;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RepositoryLayer.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly SDirectContext _context;

        public UserRepository(SDirectContext context)
        {
            _context = context;
        }

        public async Task<ArpiUser> AddUser(ArpiUser user)
        {
            _context.ArpiUsers.Add(user);
            await _context.SaveChangesAsync();
            return user;
        }

        public async Task<ArpiUser> GetUserByConfirmationToken(string token)
        {
            return await _context.ArpiUsers.FirstOrDefaultAsync(u => u.JwtToken == token);
        }

        public async Task<ArpiUser> GetUserById(int id)
        {
            return await _context.ArpiUsers.FindAsync(id);
        }

        public async Task<ArpiUser> GetUserByEmailAsync(string email)
        {
            return await _context.ArpiUsers.FirstOrDefaultAsync(u => u.Email == email);
        }

        public async Task<IEnumerable<ArpiUser>> GetAllUsers()
        {
            
            return await _context.ArpiUsers.ToListAsync();
        }

        public async Task UpdateUserAsync(ArpiUser user)
        {
            _context.ArpiUsers.Update(user);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteUserAsync(int id)
        {
            var user = await _context.ArpiUsers.FindAsync(id);
            if (user != null)
            {
                user.IsActive = false;
                await _context.SaveChangesAsync();
            }
        }
    }
}
