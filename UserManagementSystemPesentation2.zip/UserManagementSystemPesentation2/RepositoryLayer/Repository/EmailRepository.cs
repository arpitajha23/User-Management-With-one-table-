﻿
using DataAccessLayerr.Models;
using Microsoft.EntityFrameworkCore;
using RepositoryLayer.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryLayer.Repository
{
    public class EmailRepository : IEmailRepository
    {
        private readonly SDirectContext _context;

        public EmailRepository(SDirectContext context)
        {
            _context = context;
        }
        public async Task<ArpiUser> GetUserByEmail(string email)
        {
            return await _context.ArpiUsers.SingleOrDefaultAsync(u => u.Email == email);
        }
    }
}
