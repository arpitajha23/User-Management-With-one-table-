﻿
using DataAccessLayerr.Models;
using Microsoft.EntityFrameworkCore;
using RepositoryLayer.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryLayer.Repository
{
    public class AuthRepository : IAuthRepository
    {

        private readonly SDirectContext _context;

        public AuthRepository(SDirectContext context)
        {
            _context = context;
        }

        //login
        public async Task<ArpiUser> LoginUser(string email)
        {
            return await _context.ArpiUsers.FirstOrDefaultAsync(u => u.Email == email);
        }


        //user count
        public async Task<int> GetActiveUserCountAsync()
        {
            return await _context.ArpiUsers.CountAsync(u => u.IsActive);
        }

        public async Task<int> GetInactiveUserCountAsync()
        {
            return await _context.ArpiUsers.CountAsync(u => !(u.IsActive));
        }
    }
}
