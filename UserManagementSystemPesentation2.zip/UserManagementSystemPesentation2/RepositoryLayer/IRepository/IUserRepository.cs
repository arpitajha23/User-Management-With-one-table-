﻿using DataAccessLayerr.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryLayer.IRepository
{
    public interface IUserRepository
    {
        /*   Task AddUser(ArpiUser user);

           Task<ArpiUser> GetUserByEmailAsync(string email);
           Task UpdateUser(ArpiUser user);

           Task<IEnumerable<ArpiUser>> GetAllUsersAsync();
           Task<ArpiUser> GetUserByIdAsync(int id);*/


        Task<ArpiUser> GetUserByConfirmationToken(string token);
        Task<ArpiUser> AddUser(ArpiUser user);
        Task<ArpiUser> GetUserById(int id);
        Task<ArpiUser> GetUserByEmailAsync(string email);
        Task<IEnumerable<ArpiUser>> GetAllUsers();
        Task UpdateUserAsync(ArpiUser user);
        Task DeleteUserAsync(int id);

    }
}
