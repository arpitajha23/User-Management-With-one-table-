﻿using DataAccessLayerr.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryLayer.IRepository
{
    public interface IAuthRepository
    {
        //login
        Task<ArpiUser> LoginUser(string email);



        //User Count
        Task<int> GetActiveUserCountAsync();
        Task<int> GetInactiveUserCountAsync();

    }
}
