﻿using DataAccessLayerr.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ServiceLayer.DTO;
using ServiceLayer.IService;
using ServiceLayer.Service;
using System.Security.Claims;

namespace UserManagementSystemPesentation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {

        private readonly IAuthService _authService;

        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }

        /*private readonly IUserService _userService;*/

        /*[AllowAnonymous]*/
        [HttpPost("login")]
       public async Task<IActionResult> Login([FromBody] LoginDTO loginDTO)
       {
           if (!ModelState.IsValid)
           {
               return BadRequest(ModelState);
           }

           var token = await _authService.LoginUser(loginDTO);

           if (token == null)
           {
               return Unauthorized();
           }

           return Ok(new { Token = token });

           /*return Ok(new
           {
               Token = token,
               user.FirstName,
               user.MiddleName,
               user.ImageUrl
           });*/
       }



        [HttpPost("change-password")]
/*        [Authorize]
*/
        public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var email = User.FindFirstValue(ClaimTypes.Email);

            if (email == null)
                return Unauthorized("User is not authenticated.");

            try
            {
                await _authService.ChangePasswordAsync(email, model.OldPassword, model.NewPassword);
                return Ok("Password changed successfully.");
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }





        //resetpassword and forget password 

        [HttpPost("forgot-password")]
        public async Task<IActionResult> ForgotPassword([FromBody] ForgetPasswordDTO ForgetDto)
        {
            var result = await _authService.ForgotPasswordAsync(ForgetDto);
            if (!result)
            {
                return BadRequest(new { success = false, message = "Error sending password reset email." });
            }

            return Ok(new { success = true, message = "Password reset email sent." });
        }


        [HttpPost("reset-password")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordDTO ResetDto)
        {
            var result = await _authService.ResetPasswordAsync(ResetDto);
            if (!result)
                return BadRequest("Invalid or expired reset token.");

            return Ok("Password reset successful.");
        }


        //user count api
        [HttpGet("active-count")]
        public async Task<ActionResult<int>> GetActiveUserCount()
        {
            var count = await _authService.GetActiveUserCountAsync();
            return Ok(count);
        }

        [HttpGet("inactive-count")]
        public async Task<ActionResult<int>> GetInactiveUserCount()
        {
            var count = await _authService.GetInactiveUserCountAsync();
            return Ok(count);
        }





    }
    /*public class ChangePasswordRequest
    {
        public string OldPassword { get; set; }
        public string NewPassword { get; set; }
    }*/
    }