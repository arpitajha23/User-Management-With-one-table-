﻿using DataAccessLayerr.Models;
using ServiceLayer.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.IService
{
    public interface IUserService
    {
    /*    Task<CreateUserDTO>CreateUser(CreateUserDTO userDto);
       

        Task<IEnumerable<CreateUserDTO>> GetAllUsersAsync();
        Task<CreateUserDTO> GetUserByIdAsync(int id);*/


        Task<CreateUserDTO> CreateUser(CreateUserDTO userDto);
        Task<bool> ConfirmEmail(string token);
        Task<ArpiUser> GetUserById(int id);
        Task<ArpiUser> GetUserByEmail(string email);
        Task<IEnumerable<ArpiUser>> GetAllUsers();
        Task UpdateUser(int id, CreateUserDTO userDto);
        Task DeleteUser(int id);
    }
}
