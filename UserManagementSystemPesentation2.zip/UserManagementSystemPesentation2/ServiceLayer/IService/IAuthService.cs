﻿using ServiceLayer.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.IService
{
    public interface IAuthService
    {
        //login
        Task<string> LoginUser(LoginDTO loginDTO);

        //changepassword
        Task ChangePasswordAsync(string email, string oldPassword, string newPassword);


        //forget password
        Task<bool> ForgotPasswordAsync(ForgetPasswordDTO ForgetDto);
        Task<bool> ResetPasswordAsync(ResetPasswordDTO ResetDto);

        //user count
        Task<int> GetActiveUserCountAsync();
        Task<int> GetInactiveUserCountAsync();
    }
}
