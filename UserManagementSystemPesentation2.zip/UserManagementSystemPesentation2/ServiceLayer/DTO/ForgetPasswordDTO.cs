﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.DTO
{
    public class ForgetPasswordDTO
    {
        public string Email { get; set; } = string.Empty;
    }
}
