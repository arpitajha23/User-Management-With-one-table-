﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.DTO
{
    public class CreateUserDTO
    {
        [JsonIgnore]
        public int UserId { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? MiddleName { get; set; }
        public string? Gender { get; set; } 
        public DateTime? DateOfJoining { get; set; }
        public DateTime Dob { get; set; }
        public string? Email { get; set; } 
        public string? Passwords { get; set; }
        public bool IsActive { get; set; } = false;
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public string? ImageUrl { get; set; }
        public IFormFile? ImageFile { get; set; } 
        public string? CreatedBy { get; set; }
        public string? UpdatedBy { get; set; }
        public string? DeletedBy { get; set; }
        public string? JwtToken { get; set; }
        public DateTime? JwtTokenExpiration { get; set; }
        public string? PhoneNumber { get; set; }
        public string? AlterPhoneNumber { get; set; }
        public string? Address1 { get; set; }
        public string? City1 { get; set; }
        public string? State1 { get; set; }
        public string? Country1 { get; set; }
        public string? ZipCode1 { get; set; }
        public string? Address2 { get; set; }
        public string? City2 { get; set; }
        public string? State2 { get; set; }
        public string? Country2 { get; set; }
        public string? ZipCode2 { get; set; }
    }
}
