﻿using DataAccessLayerr.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using RepositoryLayer.IRepository;
using RepositoryLayer.Repository;
using ServiceLayer.DTO;
using ServiceLayer.IService;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Service
{
    public class AuthService : IAuthService
    {

        private readonly IAuthRepository _authRepository;
        private readonly IConfiguration _configuration;
        private readonly IUserRepository _userRepository;
        private readonly IEmailService _emailService;

        public AuthService(IAuthRepository authRepository, IConfiguration configuration, IUserRepository userRepository, IEmailService emailService)
        {
            _authRepository = authRepository;
            _configuration = configuration;
            _userRepository = userRepository;
            _emailService = emailService;
        }

        //login
        public async Task<string> LoginUser(LoginDTO loginDTO)
        {
            var user = await _authRepository.LoginUser(loginDTO.Email);


            if (user == null)
            {
                return null;
            }


            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_configuration["Jwt:Key"]);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.Email, user.Email),
                }),
                Expires = DateTime.UtcNow.AddHours(1),
                Issuer = _configuration["Jwt:Issuer"],
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }


        //change password
        public async Task ChangePasswordAsync(string email, string oldPassword, string newPassword)
        {
            var user = await _userRepository.GetUserByEmailAsync(email);

            if (user == null)
                throw new UnauthorizedAccessException("User not found.");

            if (user.Passwords != oldPassword)
                throw new UnauthorizedAccessException("Old password is incorrect.");

            user.Passwords = newPassword; // Update with the new plain text password

            await _userRepository.UpdateUserAsync(user);
        }


        //reset password and forget password
        public async Task<bool> ForgotPasswordAsync(ForgetPasswordDTO ForgetDto)
        {
            var user = await _userRepository.GetUserByEmailAsync(ForgetDto.Email);

            if (user == null)
                return false;


            var resetToken = GenerateResetToken(user.Email);
            user.JwtToken = resetToken;
            user.JwtTokenExpiration = DateTime.UtcNow.AddMinutes(30);
            await _userRepository.UpdateUserAsync(user);


            var resetLink = $"http://localhost:4200/password/resetpassword?token={resetToken}";
            var subject = "Reset Your Password";
            var body = $"<p>To reset your password, click the following link: <a href='{resetLink}'>Reset Password</a></p>";
            await _emailService.SendEmailAsync(ForgetDto.Email, subject, body);

            return true;
        }

        public async Task<bool> ResetPasswordAsync(ResetPasswordDTO ResetDto)
        {
            var user = await _userRepository.GetUserByConfirmationToken(ResetDto.Token);

            if (user == null || user.JwtTokenExpiration < DateTime.UtcNow)
                return false;

            //  user.Passwords = HashPassword(dto.NewPassword); // Hash the new password
            user.Passwords = ResetDto.NewPassword;
            user.JwtToken = null;
            user.JwtTokenExpiration = null;
            await _userRepository.UpdateUserAsync(user);

            return true;
        }

        private string GenerateResetToken(string email)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_configuration["Jwt:Key"]);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                new Claim(ClaimTypes.Email, email)
                }),
                Expires = DateTime.UtcNow.AddMinutes(30),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
                Issuer = _configuration["Jwt:Issuer"]
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        //user count
        public async Task<int> GetActiveUserCountAsync()
        {
            return await _authRepository.GetActiveUserCountAsync();
        }

        public async Task<int> GetInactiveUserCountAsync()
        {
            return await _authRepository.GetInactiveUserCountAsync();
        }

    }
}
