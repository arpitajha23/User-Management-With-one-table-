﻿using DataAccessLayerr.Helpers;
using DataAccessLayerr.Models;
using GSF.Security.Cryptography;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using RepositoryLayer.IRepository;
using ServiceLayer.DTO;
using ServiceLayer.IService;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Service
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        private readonly IEmailService _emailService;
        private readonly IConfiguration _configuration;

        public UserService(IUserRepository userRepository, IEmailService emailService, IConfiguration configuration)
        {
            _userRepository = userRepository;
            _emailService = emailService;
            _configuration = configuration;
        }

        /*       public async Task<CreateUserDTO> CreateUser(CreateUserDTO userDto)
               {*//*
                   var encryptedEmail = EncryptionHelper.Encrypt(userDto.Email);
       *//*
                   var passwordGenerator = new PasswordGenerator();
                   var password = passwordGenerator.GeneratePassword();

                   var encryptedPassword = EncryptionHelper.Encrypt(password);
                   var encryptedPhoneNumber = EncryptionHelper.Encrypt(userDto.PhoneNumber);
                   var encryptedAlterPhoneNumber = EncryptionHelper.Encrypt(userDto.AlterPhoneNumber);

                   var user = new ArpiUser
                   {
                       FirstName = userDto.FirstName,
                       LastName = userDto.LastName,
                       MiddleName = userDto.MiddleName,
                       Gender = userDto.Gender,
                       DateOfJoining = userDto.DateOfJoining,
                       Dob = userDto.Dob,
                       *//*Email = encryptedEmail,*//*
                       Email = userDto.Email,
                       Passwords = encryptedPassword,
                       IsActive = false,
                       CreatedAt = DateTime.Now,
                       UpdatedAt = DateTime.Now,
                       PhoneNumber = encryptedPhoneNumber,
                       AlterPhoneNumber = encryptedAlterPhoneNumber,
                       JwtToken = GenerateJwtToken(userDto.Email),
                       JwtTokenExpiration = DateTime.UtcNow.AddHours(24),
                       Address1 = userDto.Address1,
                       City1 = userDto.City1,
                       State1 = userDto.State1,
                       Country1 = userDto.Country1,
                       ZipCode1 = userDto.ZipCode1,
                       Address2 = userDto.Address2,
                       City2 = userDto.City2,
                       State2 = userDto.State2,
                       Country2 = userDto.Country2,
                       ZipCode2 = userDto.ZipCode2,
                   };

                   // Save Image
                   if (userDto.ImageFile != null)
                   {
                       user.ImageUrl = await SaveImage(userDto.ImageFile);
                   }

                   await _userRepository.AddUser(user);

                   var token = GenerateJwtToken(userDto.Email); // Generate token
                   var encodedToken = Uri.EscapeDataString(token); // URL encode the token
                   var confirmationLink = $"http://localhost:4200/auth/confirmuser?token={encodedToken}";

                   var subject = "Registration Successful";
                   var body = $@"
                   <p>Your registration was successful!</p>
                   <p><b>Email:</b> {userDto.Email}</p>
                   <p><b>Password:</b> {password}</p>
                   <p>Please complete your registration by logging in with the following link:</p>
                   <a href='{confirmationLink}' style='display:inline-block; padding:10px 20px; font-size:16px; color:white; background-color:blue; text-decoration:none; border-radius:5px;'>Confirm Account</a>";

                   await _emailService.SendEmailAsync(userDto.Email, subject, body);

                   return userDto;
               }

               //for confirmation mail of create user

               public async Task<bool> ConfirmEmail(string token)
               {
                   var user = await _userRepository.GetUserByConfirmationToken(token);
                   if (user == null || user.JwtTokenExpiration < DateTime.Now)
                   {
                       return false;
                   }

                   user.IsActive = true;
                   user.JwtToken = null; // Clear the token
                   user.JwtTokenExpiration = null; // Clear the token expiration
                   await _userRepository.UpdateUser(user);

                   var subject = "Email Confirmation Successful";
                   var body = "<p>Congratulations! Your email has been confirmed successfully.</p>";

                   await _emailService.SendEmailAsync(user.Email, subject, body);

                   return true;
               }

               //genrate jwt for create user
               private string GenerateJwtToken(string email)
               {
                   var tokenHandler = new JwtSecurityTokenHandler();
                   var key = Encoding.ASCII.GetBytes(_configuration["Jwt:Key"]);
                   var tokenDescriptor = new SecurityTokenDescriptor
                   {
                       Subject = new ClaimsIdentity(new Claim[]
                       {
                   new Claim(ClaimTypes.Email, email)
                       }),
                       Expires = DateTime.UtcNow.AddHours(1),
                       SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
                       Issuer = _configuration["Jwt:Issuer"]
                   };

                   var token = tokenHandler.CreateToken(tokenDescriptor);
                   return tokenHandler.WriteToken(token);
               }

               private async Task<byte[]> SaveImage(IFormFile imageFile)
               {
                   using var memoryStream = new MemoryStream();
                   await imageFile.CopyToAsync(memoryStream);
                   return memoryStream.ToArray();
               }




               //get all the user 

               public async Task<IEnumerable<CreateUserDTO>> GetAllUsersAsync()
               {
                   var users = await _userRepository.GetAllUsersAsync();
                   var userDtos = new List<CreateUserDTO>();

                   foreach (var user in users)
                   {
                       userDtos.Add(new CreateUserDTO
                       {
                           UserId = user.UserId,
                           Email = EncryptionHelper.Decrypt(user.Email),
                           PhoneNumber = EncryptionHelper.Decrypt(user.PhoneNumber),
                           AlterPhoneNumber = EncryptionHelper.Decrypt(user.AlterPhoneNumber),
                           Passwords = EncryptionHelper.Decrypt(user.Passwords),
                           ImageBase64 = Convert.ToBase64String(user.ImageUrl)
                       });
                   }

                   return userDtos;
               }


               //get user by id

               public async Task<CreateUserDTO> GetUserByIdAsync(int id)
               {
                   var user = await _userRepository.GetUserByIdAsync(id);
                   if (user == null)
                   {
                       return null;
                   }

                   return new CreateUserDTO
                   {
                       UserId = user.UserId,
                       Email = EncryptionHelper.Decrypt(user.Email),
                       PhoneNumber = EncryptionHelper.Decrypt(user.PhoneNumber),
                       AlterPhoneNumber = EncryptionHelper.Decrypt(user.AlterPhoneNumber),
                       Passwords = EncryptionHelper.Decrypt(user.Passwords),
                       ImageBase64 = Convert.ToBase64String(user.ImageUrl)
                   };
               }*/


        //get user by email


        //update user


        //delete user



        public async Task<CreateUserDTO> CreateUser(CreateUserDTO userDto)
        {
            var passwordGenerator = new PasswordGenerator();
            var password = passwordGenerator.GeneratePassword();

            var user = new ArpiUser
            {
                FirstName = userDto.FirstName,
                LastName = userDto.LastName,
                MiddleName = userDto.MiddleName,
                Gender = userDto.Gender,
                DateOfJoining = userDto.DateOfJoining,
                Dob = userDto.Dob,
                Email = userDto.Email,
                Passwords = password,
                IsActive = false,
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now,
                PhoneNumber = userDto.PhoneNumber,
                AlterPhoneNumber = userDto.AlterPhoneNumber,
                Address1 = userDto.Address1,
                City1 = userDto.City1,
                State1 = userDto.State1,
                Country1 = userDto.Country1,
                ZipCode1 = userDto.ZipCode1,
                Address2 = userDto.Address2,
                City2 = userDto.City2,
                State2 = userDto.State2,
                Country2 = userDto.Country2,
                ZipCode2 = userDto.ZipCode2,
            };

            // Save Image
            if (userDto.ImageFile != null)
            {
                user.ImageUrl = await SaveImage(userDto.ImageFile);
            }

            await _userRepository.AddUser(user);

            var token = GenerateJwtToken(userDto.Email);
            var encodedToken = Uri.EscapeDataString(token);
            var confirmationLink = $"http://localhost:4200/auth/confirmuser?token={encodedToken}";

            var subject = "Registration Successful";
            var body = $@"
                <p>Your registration was successful!</p>
                <p><b>Email:</b> {userDto.Email}</p>
                <p><b>Password:</b> {password}</p>
                <p>Please complete your registration by logging in with the following link:</p>
                <a href='{confirmationLink}' style='display:inline-block; padding:10px 20px; font-size:16px; color:white; background-color:blue; text-decoration:none; border-radius:5px;'>Confirm Account</a>";

            await _emailService.SendEmailAsync(userDto.Email, subject, body);

            return userDto;
        }


        public async Task<ArpiUser> GetUserById(int id)
        {
            /*  var user = await _userRepository.GetUserById(id);
              return new CreateUserDTO
              {
                  FirstName = user.FirstName,
                  LastName = user.LastName,
                  MiddleName = user.MiddleName,
                  Gender = user.Gender,
                  DateOfJoining = user.DateOfJoining,
                  Dob = user.Dob,
                  Email = user.Email,
                  Passwords = user.Passwords,
                  IsActive = user.IsActive,
                  PhoneNumber = user.PhoneNumber,
                  AlterPhoneNumber = user.AlterPhoneNumber,
                  Address1 = user.Address1,
                  City1 = user.City1,
                  State1 = user.State1,
                  Country1 = user.Country1,
                  ZipCode1 = user.ZipCode1,
                  Address2 = user.Address2,
                  City2 = user.City2,
                  State2 = user.State2,
                  Country2 = user.Country2,
                  ZipCode2 = user.ZipCode2,
                  ImageUrl = user.ImageUrl != null ? $"data:image/jpeg;base64,{Convert.ToBase64String(user.ImageUrl)}" : null
              };*/

            return await _userRepository.GetUserById(id);

        }

        public async Task<ArpiUser> GetUserByEmail(string email)
        {
            return await _userRepository.GetUserByEmailAsync(email);
        }

        public  Task<IEnumerable<ArpiUser>> GetAllUsers()
        {

           return _userRepository.GetAllUsers();
            
        }

        public async Task UpdateUser(int id, CreateUserDTO userDto)
        {
            var user = await _userRepository.GetUserById(id);
            if (user == null) throw new Exception("User not found");

            user.FirstName = userDto.FirstName;
            user.LastName = userDto.LastName;
            user.MiddleName = userDto.MiddleName;
            user.Gender = userDto.Gender;
            user.DateOfJoining = userDto.DateOfJoining;
            user.Dob = userDto.Dob;
            user.IsActive = userDto.IsActive;
            user.UpdatedAt = DateTime.Now;
            user.PhoneNumber = userDto.PhoneNumber;
            user.AlterPhoneNumber = userDto.AlterPhoneNumber;
            user.Address1 = userDto.Address1;
            user.City1 = userDto.City1;
            user.State1 = userDto.State1;
            user.Country1 = userDto.Country1;
            user.ZipCode1 = userDto.ZipCode1;
            user.Address2 = userDto.Address2;
            user.City2 = userDto.City2;
            user.State2 = userDto.State2;
            user.Country2 = userDto.Country2;
            user.ZipCode2 = userDto.ZipCode2;

            if (userDto.ImageFile != null)
            {
                user.ImageUrl = await SaveImage(userDto.ImageFile);
            }

            await _userRepository.UpdateUserAsync(user);
        }




        public async Task DeleteUser(int id)
        {
            await _userRepository.DeleteUserAsync(id);
        }

        //for confirmation mail of create user
        public async Task<bool> ConfirmEmail(string token)
        {
            var user = await _userRepository.GetUserByConfirmationToken(token);
            if (user == null || user.JwtTokenExpiration < DateTime.Now)
            {
                return false;
            }

            user.IsActive = true;
            user.JwtToken = null; // Clear the token
            user.JwtTokenExpiration = null; // Clear the token expiration
            await _userRepository.UpdateUserAsync(user);

            var subject = "Email Confirmation Successful";
            var body = "<p>Congratulations! Your email has been confirmed successfully.</p>";

            await _emailService.SendEmailAsync(user.Email, subject, body);

            return true;
        }

        //generate jwt for create user
        private string GenerateJwtToken(string email)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_configuration["Jwt:Key"]);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                new Claim(ClaimTypes.Email, email)
                }),
                Expires = DateTime.UtcNow.AddHours(1),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
                Issuer = _configuration["Jwt:Issuer"]
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        private async Task<byte[]> SaveImage(IFormFile imageFile)
        {
            using var memoryStream = new MemoryStream();
            await imageFile.CopyToAsync(memoryStream);
            return memoryStream.ToArray();
        }
    }
}


