import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError,  tap } from 'rxjs/operators';

interface LoginDto {
  email: string;
  password: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthserviceService {
  private apiUrl = "http://localhost:5147/api/Auth";
       
  
  
  constructor(private http: HttpClient) { }

  login(credentials: { email: string; password: string }): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/login`, credentials);
  }
  

   //user count
   getActiveUserCount(): Observable<number> {
    return this.http.get<number>(`${this.apiUrl}/active-count`);
  }

  getInactiveUserCount(): Observable<number> {
    return this.http.get<number>(`${this.apiUrl}/inactive-count`);
  }

 // password reset
 forgotPassword(email: string): Observable<any> {
  return this.http.post(`${this.apiUrl}/forgot-password`,{ email});
}

// Reset password
resetPassword(token: string, newPassword: string): Observable<any> {
  return this.http.post(`${this.apiUrl}/reset-password`, { token, newPassword });
}

changePassword(data: { oldPassword: string; newPassword: string }): Observable<any> {
  return this.http.post(`${this.apiUrl}/change-password`, data);
}

 

 
}
