import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CreateUserDTO } from '../models/create-user-dto';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  private apiUrl = "http://localhost:5147/api/User";
 
  constructor(private http: HttpClient) { }


  // constructor(private http: HttpClient) { }

  // createUser(formData: FormData): Observable<any> {
  //   return this.http.post<any[]>(`${this.apiUrl}/create`, formData);
  // }

  createUser(userDto: CreateUserDTO): Observable<any> {
    const formData = new FormData();

    for (const key in userDto) {
      if (userDto.hasOwnProperty(key)) {
        const value = (userDto as any)[key];
        if (value !== undefined && value !== null) {
          formData.append(key, value);
        }
      }
    }

    return this.http.post(`${this.apiUrl}/create`, formData);
  }

  confirmEmail(token: string): Observable<boolean> {
    return this.http.post<boolean>(`${this.apiUrl}/confirm`, { token });
  }

 

  // Get list of users
  getUsers(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}`);
  }


  //create user
  // createUser(user: any): Observable<any>  {
  //   return this.http.post<any>(this.apiUrl, user);
  // }

  // Update user method
  deleteUser(id: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/${id}`);
  }
  

  // Update user method
  getUserById(id: number): Observable<CreateUserDTO> {
    return this.http.get<CreateUserDTO>(`${this.apiUrl}/${id}`);
  }

  updateUser(id: number, formData: FormData): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/update/${id}`, formData);
  }
  

 
}
