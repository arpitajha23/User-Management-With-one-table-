import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { ConfirmuserComponent } from './confirmuser/confirmuser.component';
import { authGuard } from '../guards/auth.guard';

const routes: Routes = [
  {path:'changepassword', component: ChangepasswordComponent, canActivate: [authGuard]},
  {path:'signup', component: SignUpComponent},
  {path: 'confirmuser', component: ConfirmuserComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
