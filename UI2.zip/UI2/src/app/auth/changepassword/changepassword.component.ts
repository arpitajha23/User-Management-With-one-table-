import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { UserService } from '../../Service/user.service';
import { CommonModule } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { AuthserviceService } from '../../Service/authservice.service';

@Component({
  selector: 'app-changepassword',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule, FormsModule],
  templateUrl: './changepassword.component.html',
  styleUrl: './changepassword.component.css'
})
export class ChangepasswordComponent {
  changePasswordForm: FormGroup;
  isPasswordChanged = false;

  constructor(private fb: FormBuilder, private authService: AuthserviceService,  private toastr: ToastrService) {
    this.changePasswordForm = this.fb.group({
      oldPassword: ['', [Validators.required]],
      newPassword: ['', [Validators.required, Validators.minLength(4)]],
      confirmPassword: ['', [Validators.required, Validators.minLength(4)]]
  }, { validator: this.passwordMatchValidator });
    
  }

  
  onSubmit() {
    if (this.changePasswordForm.invalid) {
      this.toastr.error('Please fill in all required fields correctly.', 'Validation Error');
      return;
    }
  
    const { oldPassword, newPassword, confirmPassword } = this.changePasswordForm.value;
    //const { oldPassword, newPassword} = this.changePasswordForm.value;
    const confirmed = window.confirm('Are you sure you want to change your password?');

    if (this.changePasswordForm.invalid) {
      console.log('Form is invalid');
      return;
    }
  
    if (newPassword !== confirmPassword) {
      console.log(`Passwords do not match: ${newPassword} !== ${confirmPassword}`);
      return;
    }
  
    this.authService.changePassword(this.changePasswordForm.value).subscribe(
      response => {
        this.isPasswordChanged = true;
      },
      error => {
        console.error('Error changing password', error);
      }
    );
  }
  passwordMatchValidator(formGroup: FormGroup) {
    const newPassword = formGroup.get('newPassword')?.value;
    const confirmPassword = formGroup.get('confirmPassword')?.value;
  
    return newPassword === confirmPassword ? null : { mismatch: true };
  }
}
