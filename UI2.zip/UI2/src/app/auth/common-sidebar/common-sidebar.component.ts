import { Component } from '@angular/core';

@Component({
  selector: 'app-common-sidebar',
  standalone: true,
  imports: [],
  templateUrl: './common-sidebar.component.html',
  styleUrl: './common-sidebar.component.css'
})
export class CommonSidebarComponent {

}
