import { Component } from '@angular/core';
import { CommonSidebarComponent } from '../common-sidebar/common-sidebar.component';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-confirmuser',
  standalone: true,
  imports: [CommonSidebarComponent,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    MatCardModule],
  templateUrl: './confirmuser.component.html',
  styleUrl: './confirmuser.component.css'
})
export class ConfirmuserComponent {

  private baseUrl = "http://localhost:5147/api/Auth"; 
  loading = true;
  error: string | null = null;

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    private toastr: ToastrService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const token = this.route.snapshot.queryParamMap.get('token');
    if (token) {
      this.confirmEmail(token);
    } else {
      this.error = 'Invalid token';
      this.loading = false;
    }
  }

  confirmEmail(token: string): void {
    this.http.get(`${this.baseUrl}/confirm/${token}`)
      .subscribe({
        next: (response: any) => {
          this.toastr.success(response.message, 'Success');
          this.loading = false;
          this.router.navigate(['/login']);
        },
        error: (error: any) => {
          console.error('Error details:', error); // Log the entire error object
          this.error = (error?.error?.message) || 'Email confirmation failed';
          this.loading = false;
        }
      });
  }
  

}
