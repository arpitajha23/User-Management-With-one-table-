import { Routes } from '@angular/router';
import { SignUpComponent } from './auth/sign-up/sign-up.component';
import { SidebarComponent } from './commonmodule/sidebar/sidebar.component';
import { authGuard } from './guards/auth.guard';




export const routes: Routes = [
    {path: '', component:SignUpComponent},
    { path: 'sidebar',component:SidebarComponent, canActivate: [authGuard] },
    { path: 'dashboard', loadChildren: () => import('./dashboard/dashboard-routing.module').then(m => m.DashboardRoutingModule), canActivate: [authGuard] },
    { path: 'auth', loadChildren: () => import('./auth/auth-routing.module').then(m => m.AuthRoutingModule) },
    { path: 'password', loadChildren: () => import('./passwordss/passwordss-routing.module').then(m => m.PasswordssRoutingModule) },
    { path: '**', component: SignUpComponent } 
];
