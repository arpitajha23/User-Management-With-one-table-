import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatMenuModule } from '@angular/material/menu';
import { SidebarComponent } from '../sidebar/sidebar.component';
import { MatSidenav, MatSidenavModule } from '@angular/material/sidenav';
import { Router } from '@angular/router';
import { SidebarServiceService } from '../../Service/sidebar-service.service';


@Component({
  selector: 'app-mainmenu',
  standalone: true,
  imports: [
    CommonModule,
    MatToolbarModule,
    MatIconModule,
    MatButtonModule,
    MatMenuModule,
    MatSidenavModule,
    MatToolbarModule,
  
  ],
  templateUrl: './mainmenu.component.html',
  styleUrl: './mainmenu.component.css'
})
export class MainmenuComponent {
 
//   userName: string = 'Lima Taylor';
//   isSidebarCollapsed: boolean = false
//   dropdownOpen = false;

//   constructor(private router: Router) {}

//   toggleDropdown(): void {
//     this.dropdownOpen = !this.dropdownOpen;
//   }

//   changePassword(): void {
//     this.dropdownOpen = false;
//     this.router.navigate(['/change-password']);
//   }
  
//   logout(): void {
//     this.dropdownOpen = false;

//     localStorage.removeItem('authToken');
//     localStorage.removeItem('userInfo');

//     sessionStorage.removeItem('authToken');
//     sessionStorage.removeItem('userInfo');
//     console.clear();
//     console.log('User logged out and session cleared.');
//     this.router.navigate(['']);
// }
isSidebarCollapsed = false;
userName: string | null = 'Arpita Kumari';
// imageUrl: string | null = '';

constructor(private sidebarService: SidebarServiceService, private router : Router) {
  this.sidebarService.sidebarCollapsed$.subscribe(
    (collapsed) => this.isSidebarCollapsed = collapsed
  );
}
// ngOnInit(): void {
//   const firstName = localStorage.getItem('firstName');
//   const middleName = localStorage.getItem('middleName');
//   this.userName = `${firstName} ${middleName}`;
//   this.imageUrl = localStorage.getItem('imageUrl');
// }

toggleSidebar() {
  this.sidebarService.toggleSidebar();
}
logout() {
  // this.dropdownOpen = false;

      localStorage.removeItem('token');
      localStorage.removeItem('userInfo');
  
      sessionStorage.removeItem('token');
      sessionStorage.removeItem('userInfo');
      console.clear();
      console.log('User logged out and session cleared.');
      this.router.navigate(['']);

}

changePassword() {
  this.router.navigate(['auth/changepassword']);
}
}
