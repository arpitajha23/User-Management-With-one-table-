import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { Route, RouterModule } from '@angular/router';
import { SidebarServiceService } from '../../Service/sidebar-service.service';
import {Router} from '@angular/router'
@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [ 
    RouterModule,
    CommonModule,
    MatIconModule,
    MatDividerModule,
    MatListModule,
    MatListModule,
    MatButtonModule,
    MatSidenavModule,
    MatToolbarModule,
    MatIconModule,
    MatButtonModule,
    MatMenuModule,
    MatSidenavModule,
    MatToolbarModule,
  ],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.css'
})
export class SidebarComponent {
  // isSidebarCollapsed = false;
  // isSubMenuOpen = false;

  // toggleSidebar() {
  //   this.isSidebarCollapsed = !this.isSidebarCollapsed;
  // }

  // toggleSubMenu() {
  //   this.isSubMenuOpen = !this.isSubMenuOpen;
  // }
  
  isSidebarCollapsed = false;
  isSubMenuOpen = false; // Track sub-menu state

  constructor(private sidebarService: SidebarServiceService,private route:Router) {
    this.sidebarService.sidebarCollapsed$.subscribe(
      (collapsed) => this.isSidebarCollapsed = collapsed
    );
  }

  toggleSubMenu() {
    this.isSubMenuOpen = !this.isSubMenuOpen;
  }
  onClick(){
    this.route.navigate(['/dashboard/adduser'])
  }
}
