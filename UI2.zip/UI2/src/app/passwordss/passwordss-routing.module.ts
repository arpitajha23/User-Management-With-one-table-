import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { ResetLinkComponent } from './reset-link/reset-link.component';

const routes: Routes = [
  {path:'forgetpassword', component: ForgetPasswordComponent},
  {path:'resetpassword', component: ResetPasswordComponent},
  {path:'resetlink', component: ResetLinkComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PasswordssRoutingModule { }
