import { Component } from '@angular/core';
import { CommonSidebarComponent } from '../../auth/common-sidebar/common-sidebar.component';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { AuthserviceService } from '../../Service/authservice.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-forget-password',
  standalone: true,
  imports: [CommonSidebarComponent,
    CommonModule,
    MatButtonModule,
    MatInputModule,
    MatCardModule,
    MatIconModule,
    ReactiveFormsModule,
    FormsModule

  ],
  templateUrl: './forget-password.component.html',
  styleUrl: './forget-password.component.css'
})
export class ForgetPasswordComponent {
  loginForm: FormGroup;

  constructor(private fb: FormBuilder, private authService: AuthserviceService,
    private route: Router, private toastr: ToastrService) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]]
    });
  }

  // onSubmit() {
  //   if (this.loginForm.valid) {
  //     this.authService.forgotPassword(this.loginForm.value.email).subscribe({
  //       next: () => {
  //         this.toastr.success('Password reset email sent.', 'Success');
  //         this.route.navigate(['password/resetlink']);
  //       },
  //       error: () => {
  //         this.toastr.error('Error sending password reset email.', 'Error');
  //       }
  //     });


  //   }}



  onSubmit() {
    if (this.loginForm.valid) {
      this.authService.forgotPassword(this.loginForm.value.email).subscribe({
        next: () => {
          this.toastr.success('Password reset email sent.', 'Success');
          this.route.navigate(['password/resetlink']);
        },
        error: (err) => {
          console.error(err); 
          this.toastr.error('Error sending password reset email.', 'Error');
        }
      });
    }
  }
}
