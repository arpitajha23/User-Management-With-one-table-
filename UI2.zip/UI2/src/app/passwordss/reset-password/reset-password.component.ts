import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { UserService } from '../../Service/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { CommonModule } from '@angular/common';
import { CommonSidebarComponent } from '../../auth/common-sidebar/common-sidebar.component';
import { BrowserModule } from '@angular/platform-browser';
import { MatFormFieldModule } from '@angular/material/form-field';
import { HttpClientModule } from '@angular/common/http';
import { AuthserviceService } from '../../Service/authservice.service';


@Component({
  selector: 'app-reset-password',
  standalone: true,
  imports: [CommonSidebarComponent,
    // BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    CommonModule],
  templateUrl: './reset-password.component.html',
  styleUrl: './reset-password.component.css'
})
export class ResetPasswordComponent implements OnInit {
  resetForm: FormGroup;
  token: string | null = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthserviceService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.resetForm = this.fb.group({
      newPassword: ['', Validators.required]
    });

    this.token = this.route.snapshot.queryParamMap.get('token');
  }
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  onSubmit() {
    if (this.resetForm.valid && this.token) {
      this.authService.resetPassword(this.token, this.resetForm.value.newPassword).subscribe({
        next: () => {
          alert('Password reset successful.');
          this.router.navigate(['/auth/signin']);
        },
        error: () => alert('Invalid or expired reset token.')
      });
    }
  }
  // onSubmit(): void {
  //   if (this.resetPasswordForm.valid && this.token) {
  //     const newPassword = this.resetPasswordForm.value.newPassword;
  //     this.userService.resetPassword(this.token, newPassword).subscribe(
  //       () => {
  //         alert('Password reset successfully');
  //         this.router.navigate(['login']);
  //       },
  //       error => {
  //         console.error('Error resetting password', error);
  //         alert('Error resetting password');
  //       }
  //     );
  //   }
  // }
}
