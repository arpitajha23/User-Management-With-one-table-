import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MainmenuComponent } from '../../commonmodule/mainmenu/mainmenu.component';
import { CommonModule } from '@angular/common';
import { SidebarComponent } from '../../commonmodule/sidebar/sidebar.component';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { UserService } from '../../Service/user.service';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { Router } from '@angular/router';
//import { ToastrService } from 'ngx-toastr';
import { AuthserviceService } from '../../Service/authservice.service';
import { SidebarServiceService } from '../../Service/sidebar-service.service';
import { ToastrService } from 'ngx-toastr';
import { EncryptionService } from '../../Service/encryption.service';



// interface User
//   firstName: string;
//   middleName: string
//   lastName: string;
//   dob: string;
//   email: string;
//   contactNo: string;
//   city: string;
//   state: string;
// }
@Component({
  selector: 'app-user-list',
  standalone: true,
  imports: [MainmenuComponent,
   // UserService,
    CommonModule,
    SidebarComponent,
    MatButtonModule,
    MatIconModule
    
  ],
  templateUrl: './user-list.component.html',
  styleUrl: './user-list.component.css'
})
export class UserListComponent implements OnInit {

  isSidebarCollapsed = false;
  activeUsers: number = 0;
  inactiveUsers: number = 0;

  users: any[] = [];
  paginatedUsers: any[] = [];
  currentPage: number = 1;
  itemsPerPage: number = 4;
  totalPages: number = 1;

  constructor(
    private authService: AuthserviceService,
    private userService: UserService,
    private route:Router,
    private encryptionService: EncryptionService,
    private sidebarService: SidebarServiceService,
    private toastr: ToastrService) {
      this.sidebarService.sidebarCollapsed$.subscribe(
        (collapsed) => this.isSidebarCollapsed = collapsed
      );
    }

  ngOnInit(): void {
    this.loadUserCounts();
    this.loadUsers();
  }

  loadUserCounts(): void {
    this.authService.getActiveUserCount().subscribe(count => this.activeUsers = count);
    this.authService.getInactiveUserCount().subscribe(count => this.inactiveUsers = count);
  }

  loadUsers(): void {
    this.userService.getUsers().subscribe({
      next: (res: any) => {
        this.users = res;
        this.totalPages = Math.ceil(this.users.length / this.itemsPerPage);
        this.updatePagination();
      },
      error: (err: any) => {
        console.error("Error fetching users", err);
        this.toastr.error('Error fetching user data.', 'Error');
      },
    });
  }

  updatePagination(): void {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    this.paginatedUsers = this.users.slice(startIndex, endIndex);
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.updatePagination();
    }
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.updatePagination();
    }
  }

  sortData(column: string): void {
    this.users.sort((a, b) => {
      if (a[column] < b[column]) {
        return -1;
      } else if (a[column] > b[column]) {
        return 1;
      }
      return 0;
    });
    this.updatePagination();
  }

  toggleMenu(user: any): void {
    user.showMenu = !user.showMenu;
  }

  // edit(user: any): void {
  //   // console.log(user.userId)
    
  //   this.route.navigate(['/dashboard/edit', user.userId]);
  // }

  edit(user: any): void {
    const encryptedId = this.encryptionService.encrypt(user.userId.toString());
    this.route.navigate(['/dashboard/edit', encryptedId]);
  }


  confirmAndDelete(user: any): void {
    if (confirm('Are you sure you want to delete this user?')) {
      console.log('Deleting user with ID:', user.userId); 
      this.deleteUser(user.userId);
    }
  }

  deleteUser(userId: number): void {
    this.userService.deleteUser(userId).subscribe({
      next: () => {
        this.toastr.success('User deleted successfully.', 'Success');
        this.loadUsers();
      },
      error: (err) => {
        console.error('Error deleting user:', err);
        this.toastr.error('Error deleting user.', 'Error');
      }
    });
  }

  // exportToExcel(): void {
  //   try {
  //     const workbook = XLSX.utils.book_new();
  //     const worksheet = XLSX.utils.json_to_sheet(this.users);

  //     XLSX.utils.book_append_sheet(workbook, worksheet, 'Users');
  //     const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  //     const blob = new Blob([wbout], { type: 'application/octet-stream' });
  //     saveAs(blob, 'users.xlsx');
  //     this.toastr.success('Users exported successfully.', 'Success');
  //   } catch (error) {
  //     console.error('Error exporting data:', error);
  //     this.toastr.error('Error exporting data.', 'Error');
  //   }
  // }

  exportToExcel(): void {
    try {
      const usersToExport = this.users.map(user => {
        return {
          id: user.id,
          firstName: user.firstName,
          lastName: user.lastName,
          email: user.email,
          phoneNumber: user.phoneNumber
        };
      });
  
      const workbook = XLSX.utils.book_new();
      const worksheet = XLSX.utils.json_to_sheet(usersToExport);
  
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Users');
      const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      const blob = new Blob([wbout], { type: 'application/octet-stream' });
      saveAs(blob, 'users.xlsx');
      this.toastr.success('Users exported successfully.', 'Success');
    } catch (error) {
      console.error('Error exporting data:', error);
      this.toastr.error('Error exporting data.', 'Error');
    }
  }
  
}
