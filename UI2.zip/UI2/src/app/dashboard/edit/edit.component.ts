import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../Service/user.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { SidebarComponent } from '../../commonmodule/sidebar/sidebar.component';
import { MainmenuComponent } from '../../commonmodule/mainmenu/mainmenu.component';
import { ToastrService } from 'ngx-toastr';
import { EncryptionService } from '../../Service/encryption.service';

@Component({
  selector: 'app-edit',
  standalone: true,
  imports: [SidebarComponent, CommonModule, ReactiveFormsModule, MainmenuComponent],
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  userForm: FormGroup;
  userId: any | undefined;
  imagePreviewUrl: any | ArrayBuffer | null = null;
  selectedImageFile: File | null = null; // Store the selected image file

  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    private router: Router,
    private encryptionService: EncryptionService,
    private route: ActivatedRoute,
    private toastr: ToastrService
  ) {
    this.userForm = this.fb.group({
      firstName: ['', Validators.required],
      middleName: [''],
      lastName: ['', Validators.required],
      gender: ['', Validators.required],
      dob: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      doj: ['', Validators.required],
      phoneNumber: ['', Validators.required],
      alterPhoneNumber: [''],
      address1: [''],
      address2: [''],
      city1: [''],
      state1: [''],
      city2: [''],
      state2: [''],
      country1: [''],
      country2: [''],
      zipCode1: [''],
      zipCode2: [''],
      isActive: [''],
      imageFile: [null] // Add the image file control
    });
  }

  // ngOnInit(): void {
  //   this.route.paramMap.subscribe(params => {
  //     this.userId = +params.get('id')!;
  //     if (this.userId) {
  //       this.loadUserData();
  //     } else {
  //       console.error('User ID is missing');
  //       this.router.navigate(['/dashboard/userlist']);
  //     }
  //   });
  // }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const encryptedId = params.get('id');
      if (encryptedId) {
        this.userId = +this.encryptionService.decrypt(encryptedId);
        if (this.userId) {
          this.loadUserData();
        } else {
          console.error('User ID is invalid');
          this.router.navigate(['/dashboard/userlist']);
        }
      } else {
        console.error('User ID is missing');
        this.router.navigate(['/dashboard/userlist']);
      }
    });
  }

  loadUserData(): void {
    this.userService.getUserById(this.userId).subscribe(user => {
      this.userForm.patchValue({
        firstName: user.firstName,
        middleName: user.middleName,
        lastName: user.lastName,
        gender: user.gender,
        dob: user.dob ? new Date(user.dob).toISOString().split('T')[0] : '', 
        doj: user.dateOfJoining ? new Date(user.dateOfJoining).toISOString().split('T')[0] : '',  
        email: user.email,
        phoneNumber: user.phoneNumber,
        alterPhoneNumber: user.alterPhoneNumber,
        address1: user.address1,
        address2: user.address2,
        city1: user.city1,  
        state1: user.state1,
        city2: user.city2,
        state2: user.state2,
        country1: user.country1,
        country2: user.country2,
        zipCode1: user.zipCode1,
        zipCode2: user.zipCode2,
        isActive: user.isActive,
        imageFile: null // Clear any previously selected file
      });
  
      // If there's a Base64 image, create a URL for it
      if (user.imageUrl) {
        this.imagePreviewUrl = `data:image/png;base64,${user.imageUrl}`;
      }
    });
  }
  

  onSubmit() {
    if (this.userForm.valid) {
      const formData = new FormData();

      // Append all form data fields to FormData object
      Object.keys(this.userForm.controls).forEach(key => {
        const value = this.userForm.get(key)?.value;
        if (value !== undefined && value !== null) {
          formData.append(key, value);
        }
      });

      // Append image file to FormData if present
      if (this.selectedImageFile) {
        formData.append('imageFile', this.selectedImageFile);
      }

      this.userService.updateUser(this.userId, formData).subscribe({
        next: (response) => {
          this.toastr.success("User updated successfully");
          this.router.navigate(['dashboard/userlist']);
        },
        error: (err) => {
          console.error("Error updating user", err);
          this.toastr.error("Error updating user");
        }
      });
    } else {
      console.error("Form is invalid");
      this.toastr.error("Form is invalid");
    }
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      this.selectedImageFile = input.files[0];

      // For previewing the image
      const reader = new FileReader();
      reader.onload = () => {
        this.imagePreviewUrl = reader.result;
      };
      reader.readAsDataURL(this.selectedImageFile);
    }
  }

  onCancel(): void {
    if (confirm('Are you sure you want to cancel? Unsaved changes will be lost.')) {
      this.router.navigate(['/dashboard/userlist']);
    }
  }
}
