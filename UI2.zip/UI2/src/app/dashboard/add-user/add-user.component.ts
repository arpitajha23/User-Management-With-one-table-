import { Component, OnInit } from '@angular/core';
// import { MatSidenavModule } from '@angular/material/sidenav';
// import { MatToolbarModule } from '@angular/material/toolbar';
// import { MatIconModule } from '@angular/material/icon';
// import { MatListModule } from '@angular/material/list';
// import { MatButtonModule } from '@angular/material/button';
// import { MatFormFieldModule } from '@angular/material/form-field';
// import { MatInputModule } from '@angular/material/input';
// import { MatSelectModule } from '@angular/material/select';
// import { MatDatepickerModule } from '@angular/material/datepicker';
// import { MatNativeDateModule } from '@angular/material/core';
// import { MatCheckboxModule } from '@angular/material/checkbox';
// import { MatCardModule } from '@angular/material/card';
import { SidebarComponent } from '../../commonmodule/sidebar/sidebar.component';
import { MainmenuComponent } from '../../commonmodule/mainmenu/mainmenu.component';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { UserService } from '../../Service/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Country, State } from 'country-state-city';
import { CommonModule } from '@angular/common';
// import { ToastrService } from 'ngx-toastr';
import { CreateUserDTO } from '../../models/create-user-dto';
import { HttpClientModule } from '@angular/common/http';
import { SidebarServiceService } from '../../Service/sidebar-service.service';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-add-user',
  standalone: true,
  imports: [

    SidebarComponent,
    MainmenuComponent,
    ReactiveFormsModule,
    CommonModule,
    HttpClientModule
  ],
  templateUrl: './add-user.component.html',
  styleUrl: './add-user.component.css'
})
export class AddUserComponent implements OnInit {


  userForm: FormGroup;
  isSidebarCollapsed = false;
  selectedImageFile: File | null = null;
  selectedImageUrl: string | ArrayBuffer | null = null;
  // countryList: any[] = [];
  // stateList: any[] = [];
  maxDob!: string;

  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    private router: Router,
    private route: ActivatedRoute,
    private sidebarService: SidebarServiceService,
    private toastr: ToastrService
  ) {
    this.userForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      middleName: [''],
      gender: ['', Validators.required],
      dateOfJoining: ['', Validators.required],
      dob: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phoneNumber: ['', Validators.required, Validators.pattern('^[0-9]{10}$')],
      alterPhoneNumber: ['',Validators.pattern('^[0-9]{10}$')],
      address1: ['', Validators.required],
      city1: ['', Validators.required],
      state1: ['', Validators.required],
      country1: ['', Validators.required],
      zipCode1: ['', Validators.required],
      address2: [''],
      city2: [''],
      state2: [''],
      country2: [''],
      zipCode2: [''],
      isActive: [false],
      imageFile: [null],
    });


    this.setMaxDob();

    this.sidebarService.sidebarCollapsed$.subscribe((collapsed) => {
      console.log(this.isSidebarCollapsed, 'collapse:-');
      this.isSidebarCollapsed = collapsed;
    });
  }

  onFileSelected(event: any): void {
    const file: File = event.target.files[0];
    if (file) {
      this.selectedImageFile = file;


      const reader = new FileReader();
      reader.onload = () => {
        this.selectedImageUrl = reader.result;
      };
      reader.readAsDataURL(file);
      this.userForm.patchValue({ imageFile: file });
    }
  }


  onSubmit(): void {
    if (this.userForm.valid) {
      const formData: CreateUserDTO = this.userForm.value;
      if (this.selectedImageFile) {
        formData.imageUrl = this.selectedImageFile;
      }

      this.userService.createUser(formData).subscribe(
        (response) => {
          // alert('User created successfully');
          this.router.navigate(['dashboard/userlist']);
          this.toastr.success("user created sucessfully")
        },
        (error) => {
          console.error('Error creating user:', error);
        }
      );
    }
  }

  goBack(): void {
    this.router.navigate(['dashboard/userlist']);
  }

  ngOnInit(): void {
    //  this.countryList = Country.getAllCountries();
  }

  // onCountryChange(event: Event): void {
  //   const selectElement = event.target as HTMLSelectElement;
  //   const countryIsoCode = selectElement.value;
  //   this.stateList = State.getStatesOfCountry(countryIsoCode);
  // }


  setMaxDob(): void {
    const today = new Date();
    const day = ('0' + today.getDate()).slice(-2);
    const month = ('0' + (today.getMonth() + 1)).slice(-2);
    const year = today.getFullYear();
    this.maxDob = `${year}-${month}-${day}`;
  }

  onDateOfJoiningChange(): void {
    const dojControl = this.userForm.get('dateOfJoining');
    const dobControl = this.userForm.get('dob');
    
    if (dojControl?.value) {
      dobControl?.setValidators([Validators.required, Validators.max(dojControl.value)]);
      dobControl?.updateValueAndValidity();
    }
  }

}
