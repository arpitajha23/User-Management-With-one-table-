export interface CreateUserDTO {
  id?: number; // Adjusted from `Id` to `id` to match common naming conventions
  firstName?: string; // Made optional to match backend
  lastName?: string; // Made optional to match backend
  middleName?: string; // Optional as in backend
  gender?: string; // Optional as in backend
  dateOfJoining?: Date; // Made optional to match backend
  dob: Date; // Required as per backend
  email?: string; // Optional to match backend
  phoneNumber?: string; // Optional to match backend
  alterPhoneNumber?: string; // Optional as in backend
  address1?: string; // Optional as in backend
  city1?: string; // Optional as in backend
  state1?: string; // Optional as in backend
  country1?: string; // Optional as in backend
  zipCode1?: string; // Optional as in backend
  address2?: string; // Optional as in backend
  city2?: string; // Optional as in backend
  state2?: string; // Optional as in backend
  country2?: string; // Optional as in backend
  zipCode2?: string; // Optional as in backend
  imageUrl?: File; // Optional, corresponds to `ImageFile` in backend
  // passwords?: string; // Not used in frontend
  isActive?: boolean; // Not used in frontend
}
