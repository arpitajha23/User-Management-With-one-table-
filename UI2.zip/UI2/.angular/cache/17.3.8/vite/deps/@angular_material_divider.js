import {
  MatDivider,
  MatDividerModule
} from "./chunk-UOMBWC2J.js";
import "./chunk-XN2DVRU6.js";
import "./chunk-U5TRETMT.js";
import "./chunk-LGCHCEQT.js";
import "./chunk-4J25ECOH.js";
import "./chunk-X6JV76XL.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
